﻿

public class NodePosition {
    public int x;
    public int y;

    public NodePosition(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

}
