﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Algorithm : MonoBehaviour {
	public static Algorithm algo;
	// Use this for initialization
	void Start () {
		algo = new Algorithm ();
	}

	// Update is called once per frame
	void Update () {
		
	}
}
