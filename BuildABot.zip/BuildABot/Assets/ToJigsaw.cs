﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ToJigsaw : MonoBehaviour {

    public void OnMouseButton()
    {
        SceneManager.LoadScene("AIProgramming");
    }

}
